import Vue from 'vue';
import VueRouter from 'vue-router';
import Home from '../views/Home.vue';
import Qna from '../views/Qna.vue';

Vue.use(VueRouter);

const routes = [
  {
    path: '/',
    name: 'Home',
    component: Home,
  },
  {
    name: 'qna',
    path: '/qna',
    component: Qna,
    children: [
      {
        path: '',
        name: 'qna-list',
        component: () => import('@/components/qna/QnaList.vue'),
      },
      {
        path: 'create',
        name: 'qna-create',
        component: () => import('@/components/qna/QnaCreate.vue'),
      },
      {
        path: 'view',
        name: 'qna-view',
        component: () => import('@/components/qna/QnaView.vue'),
      },
      {
        path: 'modify/:qno',
        name: 'qna-modify',
        component: () => import('@/components/qna/QnaModify.vue'),
      },
      {
        path: 'reply/:qno',
        name: 'qna-reply',
        component: () => import('@/components/qna/QnaReply.vue'),
      },
    ],
    redirect: () => {
      return '/qna';
    },
  },
];

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes,
});

export default router;
