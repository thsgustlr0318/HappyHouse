<template>
  <div>
    <h1>메인 화면입니다.</h1>
  </div>
</template>
