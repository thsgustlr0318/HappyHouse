<template>
  <div class="about">
    <h1>SSAFY WorkShop</h1>
  </div>
</template>
