<template>
  <div>
    <write-form type="create" />
  </div>
</template>

<script>
  import WriteForm from '@/components/qna/include/WriteForm.vue';

  export default {
    name: 'qnacreate',
    components: {
      WriteForm,
    },
  };
</script>
