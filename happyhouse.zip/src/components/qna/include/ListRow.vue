<template>
  <tr>
    <td>{{ qno }}</td>
    <td>{{ chk }}</td>
    <td>{{ userid }}</td>
    <td>
      <router-link :to="`qna/view?qno=${qno}`">{{ subject }}</router-link>
    </td>
    <td>{{ content }}</td>
    <td>{{ hit }}회</td>
    <td>{{ time }}</td>
  </tr>
</template>

<script>
  export default {
    name: 'listrow',
    props: {
      qno: Number,
      chk: Number,
      userid: String,
      subject: String,
      content: String,
      hit: Number,
      time: String,
    },
    // methods: {
    //   numberWithCommas(x) {
    //     return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    //   },
    // },
  };
</script>
<style scope>
  td {
    text-align: center;
    border-bottom: 1px solid #ddd;
    height: 50px;
  }
</style>
