<template>
  <div class="regist">
    <h1 class="underline">SSAFY QnA 정보</h1>
    <div class="regist_form">
      <label for="qno">QnA번호</label>
      <div class="view">{{ qna.qno }}</div>
      <label for="chk">답변여부</label>
      <div class="view">{{ qna.chk }}</div>
      <label for="userid">아이디</label>
      <div class="view">{{ qna.userid }}</div>
      <label for="subject">제목</label>
      <div class="view">{{ qna.subject }}</div>
      <label for="content">내용</label>
      <div class="view">{{ qna.content }}</div>
      <label for="hit">조회수</label>
      <div class="view">{{ qna.hit }}</div>
      <label for="time">시간</label>
      <div class="view">{{ qna.time }}</div>
      <label for="content">설명</label>
      <div class="view" v-html="enterToBr(qna.content)"></div>
      <div style="padding-top: 15px">
        <router-link :to="`/qna/modify/${qna.qno}`" class="btn">수정</router-link>
        <a href="#" class="btn" @click="deleteQna">삭제</a>
        <router-link to="/qna" class="btn">목록</router-link>
        <router-link class="btn" :to="`/qna/reply/${qna.qno}`">답변달기</router-link>
      </div>
    </div>
    <div><h1>QnA 답변</h1></div>
  </div>
</template>

<script>
  import { mapGetters } from 'vuex';
  import http from '@/util/http-common';

  export default {
    name: 'viewdetail',
    computed: {
      ...mapGetters(['qna']),
    },
    methods: {
      deleteQna() {
        if (confirm('정말로 삭제?')) {
          http.delete(`/${this.qna.qno}`).then(({ data }) => {
            let msg = '삭제 처리시 문제가 발생했습니다.';
            if (data === 'success') {
              msg = '삭제가 완료되었습니다.';
            }
            alert(msg);
            this.$router.push('/qna');
          });
        }
      },
      // numberWithCommas(x) {
      //   if (x) return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
      // },
      enterToBr(str) {
        if (str) return str.replace(/(?:\r\n|\r|\n)/g, '<br />');
      },
    },
  };
</script>

<style scoped>
  .regist {
    padding: 10px;
  }
  .regist_form {
    text-align: left;
    border-radius: 5px;
    background-color: #f2f2f2;
    padding: 20px;
  }
  input,
  textarea,
  .view {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
    color: #787878;
    font-size: medium;
  }
</style>
