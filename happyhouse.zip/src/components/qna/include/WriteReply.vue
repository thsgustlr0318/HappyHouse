<template>
  <div class="regist">
    <h1 class="underline">
      답변
      <template>등록</template>
    </h1>
    <div class="regist_form">
      <label for="content">설명</label><br />
      <textarea id="content" name="content" v-model="content" ref="content" cols="35" rows="5"></textarea><br />
      <button @click="checkValue">등록</button>
      <button @click="moveList">목록</button>
    </div>
  </div>
</template>

<script>
  import http from '@/util/http-common';

  export default {
    name: 'writereply',
    props: {
      type: { type: String },
    },
    data() {
      return {
        content: '',
      };
    },
    created() {
      if (this.type === 'modify') {
        http.get(`answer/${this.$route.params.qno}`).then(({ data }) => {
          this.content = data.content;
        });
      }
    },
    methods: {
      // 입력값 체크하기 - 체크가 성공하면 registBook 호출
      checkValue() {
        // 사용자 입력값 체크하기
        // isbn, 제목, 저자, 가격, 설명이 없을 경우 각 항목에 맞는 메세지를 출력
        let err = true;
        let msg = '';
        !this.content && ((msg = '내용 입력해주세요'), (err = false), this.$refs.content.focus());
        if (!err) alert(msg);
        // 만약, 내용이 다 입력되어 있다면 registBook 호출
        else this.registReply();
      },
      registReply() {
        console.log(this.$route.params.qno);
        http
          .post('qna/answer/add', {
            qno: this.$route.params.qno,
            content: this.content,
          })
          .then(({ data }) => {
            console.log(data);
            let msg = '등록 처리시 문제가 발생했습니다.';
            if (data === 'success') {
              msg = '등록이 완료되었습니다.';
            }
            alert(msg);
            this.moveList();
          });
      },
      moveList() {
        this.$router.push('/qna');
      },
    },
  };
</script>

<style scoped>
  .regist {
    padding: 10px;
  }
  .regist_form {
    text-align: left;
    border-radius: 5px;
    background-color: #f2f2f2;
    padding: 20px;
  }
  input,
  textarea,
  .view {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
    color: #787878;
    font-size: medium;
  }
</style>
