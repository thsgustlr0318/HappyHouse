<template>
  <div>
    <div v-if="ans">
      <table id="ans-list">
        <colgroup>
          <col style="width: 20%" />
          <col style="width: 40%" />
          <col style="width: 20%" />
          <col style="width: 20%" />
        </colgroup>
        <thead>
          <tr>
            <th>답변 번호</th>
            <th>내용</th>
            <th>질문 번호</th>
            <th>등록 시간</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(temp, index) in ans" :key="index">
            <td>{{ temp.ano }}</td>
            <td>{{ temp.content }}</td>
            <td>{{ temp.qno }}</td>
            <td>{{ temp.time }}</td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script>
  import { mapGetters } from 'vuex';

  export default {
    name: 'viewreply',

    computed: {
      ...mapGetters(['ans']),
    },
  };
</script>

<style>
  #ans-list {
    margin-left: auto;
    margin-right: auto;
  }
</style>
