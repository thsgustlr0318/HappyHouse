<template>
  <div>
    <div v-for="(temp, index) in ans" :key="index">
      <h1>{{ temp.ano }}</h1>
      <h1>{{ temp.content }}</h1>
      <h1>{{ temp.qno }}</h1>
      <h1>{{ temp.time }}</h1>
    </div>
  </div>
</template>

<script>
  import { mapGetters } from 'vuex';

  export default {
    name: 'viewreply',

    computed: {
      ...mapGetters(['ans']),
    },
    // methods: {
    //   movePage() {
    //     this.$router.push({ name: 'qna-create' });
    //   },
    // },
  };
</script>
