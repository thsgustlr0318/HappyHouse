<template>
  <div>
    <view-detail />
    <view-reply />
  </div>
</template>

<script>
  import ViewDetail from '@/components/qna/include/ViewDetail.vue';
  import ViewReply from '@/components/qna/include/ViewReply.vue';

  export default {
    name: 'qnaview',
    components: {
      ViewDetail,
      ViewReply,
    },
    created() {
      this.$store.dispatch('getQna', `/${this.$route.query.qno}`);
      this.$store.dispatch('getAns', `/${this.$route.query.qno}`);
    },
  };
</script>
