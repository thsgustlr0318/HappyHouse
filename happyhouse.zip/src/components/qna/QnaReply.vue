<template>
  <div>
    <view-detail />
    <write-reply />
  </div>
</template>

<script>
  import ViewDetail from '@/components/qna/include/ViewDetail.vue';
  import WriteReply from '@/components/qna/include/WriteReply.vue';

  export default {
    name: 'qnaview',
    components: {
      ViewDetail,
      WriteReply,
    },
    created() {
      this.$store.dispatch('getQna', `/${this.$route.query.qno}`);
    },
  };
</script>
