<template>
  <div>
    <h1 class="underline">QnA 목록</h1>
    <div style="text-align: right">
      <button @click="movePage">QnA 등록</button>
    </div>
    <div v-if="qnas.length">
      <table id="qna-list">
        <colgroup>
          <col style="width: 5%" />
          <col style="width: 5%" />
          <col style="width: 20%" />
          <col style="width: 40%" />
          <col style="width: 20%" />
          <col style="width: 15%" />
          <col style="width: 15%" />
        </colgroup>
        <thead>
          <tr>
            <th>번호</th>
            <th>답변여부</th>
            <th>ID</th>
            <th>제목</th>
            <th>내용</th>
            <th>조회수</th>
            <th>등록 시간</th>
          </tr>
        </thead>
        <tbody>
          <list-row
            v-for="(qna, index) in qnas"
            :key="index"
            :qno="qna.qno"
            :chk="qna.chk"
            :userid="qna.userid"
            :subject="qna.subject"
            :content="qna.subject"
            :hit="qna.hit"
            :time="qna.time"
          />
        </tbody>
      </table>
    </div>
    <div v-else class="text-center">게시글이 없습니다.</div>
  </div>
</template>

<script>
  import { mapGetters } from 'vuex';
  import ListRow from '@/components/qna/include/ListRow.vue';

  export default {
    name: 'qnalist',
    components: {
      ListRow,
    },
    computed: {
      ...mapGetters(['qnas']),
    },
    created() {
      this.$store.dispatch('getQnas');
    },
    methods: {
      movePage() {
        this.$router.push({ name: 'qna-create' });
      },
    },
  };
</script>

<style scoped>
  #book-list {
    border-collapse: collapse;
    width: 100%;
  }

  #book-list thead {
    background-color: #ccc;
    font-weight: bold;
  }

  #book-list td,
  #book-list th {
    text-align: center;
    border-bottom: 1px solid #ddd;
    height: 50px;
  }

  tr:nth-child(even) {
    background-color: #f2f2f2;
  }
</style>
